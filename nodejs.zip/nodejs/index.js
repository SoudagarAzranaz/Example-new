const http = require('http');
const fs = require('fs');
const server= http.createServer(function(req , res){
    const url= req.url;
    switch (url){
        case'/':
        res.writeHead(200,{'Content-Type':'text/plain'});
            res.write("Hello World!");
            break;
            case '/about':
            res.writeHead(200,{'Content-Type':'text/plain'});

        }res.end();
    });
        server.listen(3000,function(){
            console.log("serverstarted on port 3000");
        });

       


       



    