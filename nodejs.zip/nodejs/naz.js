const http=require('http');
const fs=require('fs');
const port=3000;
http.createServer((req.res))=>{
    fs.readfile('index.html';(err,data)=>{
        if(err)throw err;
        res.writeHead(200,{'Content-Type':'Text/html'});
        res.write(data);
        res.end();
    });

    }.listen(port);
    console.log('server running on part ${port}');

