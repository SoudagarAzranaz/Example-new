function addition() 
{
let x;
x=document.getElemenyById('x_value').value;
console.log(typeof(x));
x=Number(x);
let y; 
y=document.getElementById('y_value').value;
console.log(typeof(y)); 
y=Number(y);
let z=x+y;
document.getElementById('add').innerHTML=z;
}


  